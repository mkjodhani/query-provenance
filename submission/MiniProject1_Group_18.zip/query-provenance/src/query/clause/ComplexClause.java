package query.clause;

/**
 * @author mkjodhani
 * @project
 * @since 17/10/23
 */
public class ComplexClause {
    public enum CONJUNCTION {
        AND,
        OR
    }
    private CONJUNCTION conjuction;
}
